package com.assignments;

import java.util.Scanner;

public class Question10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the degrees in Farhenheit : ");
		double far = sc.nextDouble();
		
		double cel = (far-32) * 5/(double)9;
		System.out.println(far+"�F  :  "+cel+"�C");
	}

}

