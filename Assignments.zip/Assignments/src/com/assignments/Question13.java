package com.assignments;

import java.util.Scanner;

public class Question13 {
	public static void main(String []args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter three numbers : ");
		double a = sc.nextDouble();
		double b = sc.nextDouble();
		double c = sc.nextDouble();
		
		double greatest = a>b?(a>c?a:c):(b>c?b:c);
		
		System.out.println("Greatest : "+greatest);
	}
}