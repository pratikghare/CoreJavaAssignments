package com.assignments;

import java.util.*;

public class Question23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int[10];
		
		for(int i=0; i<10; i++){
		    System.out.println("Enter element"+(i+1)+" : ");
		    arr[i] = sc.nextInt();
		}
		for(int i=0; i<10; i++){
		    System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println("Reverse : ");
		for(int i=10; i>=0; i--){
		    System.out.print(arr[i]+" ");
		}
	}
}
