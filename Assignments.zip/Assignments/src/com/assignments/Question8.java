package com.assignments;

import java.util.Scanner;

public class Question8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter the principle amount : ");
		double p = sc.nextDouble();
		System.out.println("Enter the rate of Interest : ");
		double rate = sc.nextDouble();
		System.out.println("Enter no of years : ");
		double years = sc.nextDouble();
		
		double SI = p*years*rate/100;
		
		System.out.println("Simple Interest : "+SI);
	}

}
