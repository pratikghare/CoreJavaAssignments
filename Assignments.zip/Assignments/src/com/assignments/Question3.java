package com.assignments;

import java.util.Scanner;
public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int x;
		double y;
		double z;
		System.out.println("Enter the value of x : ");
		x = sc.nextInt();
		y = (x*x) + (3*x) - 7;
		System.out.println("y = x^2 + 3x - 7\ny = "+y);
		y = x++ + ++x;
		System.out.println("y = x++ + ++x\ny = "+y+" x = "+x);
		z = x++ - --y - --x + x++;
		System.out.println("z = x++ - --y - --x + x++\nx = "+x+" y = "+y+" z = "+z);
		boolean a=true, b=false, c;
		c = a && b || !(a || b);
		System.out.println("z = x && y || !(a || b)\nx = "+a+"  y = "+b+"  z = "+c);
	}

}