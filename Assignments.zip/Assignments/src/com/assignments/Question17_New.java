package com.assignments;

import java.util.Scanner;

public class Question17_New {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your number : ");
		String str = sc.next();
		
		String rev = "";
		int len = str.length()-1;
		while(len>=0) {
			rev+=str.charAt(len);
			len--;
		}
		System.out.println("Reverse : "+rev);
	}

}