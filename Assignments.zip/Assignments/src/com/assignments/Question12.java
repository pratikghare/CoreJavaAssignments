package com.assignments;

import java.util.Scanner;

public class Question12 {
	public static void main(String []args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Basic Salary : ");
		double bs = sc.nextDouble();
		double hra, da;
		if(bs<10000) {
			hra = 0.1*bs;
			da= 0.9*bs;
		}
		else {
			hra=2000;
			da=0.98*bs;
		}
		
		double gross = bs+da+hra;
		
		System.out.println("Gross Salary : " +gross);
	}
}

