package com.assignments;

import java.util.Scanner;

public class Question9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of Days : ");
		int n = sc.nextInt();
		
		int year = n/365;
		int months = n%365;
		months=months/30;
		n=n%365;
		int days = n%31;
		System.out.println(year+"years "+months+"months "+days+"days");
	}

}