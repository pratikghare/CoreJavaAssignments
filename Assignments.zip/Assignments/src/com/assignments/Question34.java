package com.assignments;

import java.util.*;

class Circle{
    double radius;
    double Area;
    
    void init(){
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the radius : ");
        this.radius = sc.nextInt();
    }
    
    void calculateArea(){
        this.Area = 2 * 3.143 * this.radius * this.radius;
    }
    
    void display(){
        System.out.println("Area of Circle : "+this.Area);
    }
}

public class Question34 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c = new Circle();
		c.init();
		c.calculateArea();
		c.display();
	}
}