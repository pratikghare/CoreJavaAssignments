package com.assignments;

public class Question29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[][] = new int[5][3];
		int a1[] = {1, 2, 3};
		int a2[] = {4, 5, 6};
		int a3[] = {7, 8, 9};
		int a4[] = {10, 11, 12};
		int a5[] = {13, 14, 15};
		
		arr[0] = a1;
		arr[1] = a2;
		arr[2] = a3;
		arr[3] = a4;
		arr[4] = a5;

		int count = 0;
		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				count++;
			}
		}
		System.out.println("Rows : "+arr.length+ " Elements : "+count);
	}

}
