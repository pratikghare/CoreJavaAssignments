package com.assignments;

import java.util.Scanner;

public class Question19_New {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the range till you want to calculate the squares : ");
		int range = sc.nextInt();
		int num = 1;
		int sum = 0;
		while(num<=range) {
			if(num < range)
				System.out.print(num*num+" + ");
			else
					System.out.print(num*num+" = ");
			sum+=(num*num);
			num++;
		}
		System.out.println(sum);
	}

}