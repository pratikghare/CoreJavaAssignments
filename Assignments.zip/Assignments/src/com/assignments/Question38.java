package com.assignments;

import java.util.*;

class Employee{
    int empNo;
    static double totalSalary;
    double sal;
    static int empCount;
    
    
    Employee(double sal){
        this.sal = sal;
        this.empNo++;
        totalSalary+=sal;
        empCount++;
    }
    
    
    public void display(){
        System.out.println("Empcount : "+empCount+ " totalSalary : "+totalSalary);
    }
}

public class Question38 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		Employee e = new Employee(50000.00);
	    Employee e1 = new Employee(50000.00);
	    Employee e2 = new Employee(50000.00);
	    Employee e3 = new Employee(50000.00);
	    Employee e4 = new Employee(50000.00);
	    Employee e5 = new Employee(50000.00);
	    e.display();
	}
}
