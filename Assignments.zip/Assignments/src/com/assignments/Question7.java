package com.assignments;

import java.util.Scanner;

public class Question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of Subjects : ");
		int n = sc.nextInt();
		int sum=0;
		int marks;
		for (int i=0; i<n; i++) {
			System.out.println("Enter marks for Subject"+(i+1)+" out of 100 : ");
			marks=sc.nextInt();
			sum+=marks;
		}
		float per = sum/(float)n;
		
		System.out.println("Percentage : "+per+"%");
	}
}
