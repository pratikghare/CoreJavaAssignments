package com.assignments;

import java.util.Scanner;

public class Question18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your number : ");
		int num = sc.nextInt();
		int count = 0;
		for(int i=2; i<=num; i++) {
			if(num % i == 0) {
				count++;
			}
		}
		if(count == 1)
			System.out.println(num+" is a Prime number");
		else
			System.out.println(num+" is not a Prime Number");
	}

}
