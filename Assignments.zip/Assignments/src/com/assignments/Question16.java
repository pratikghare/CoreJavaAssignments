package com.assignments;

import java.util.Scanner;

public class Question16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number you want to find the table of : ");
		int n = sc.nextInt();
		
		for(int i=1; i<=10; i++) {
			System.out.println(n+" x "+i+"\t=\t"+(n*i));
		}
	}

}
