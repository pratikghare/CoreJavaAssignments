package com.assignments;

import java.util.Scanner;

public class Question30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of rows : ");
		int n = sc.nextInt();
		int arr[][] = new int[n][n];

		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				System.out.println("Enter element"+i+j+" : ");
				arr[i][j] = sc.nextInt();
			}
		}
		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		int sum = 0;
		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				if(j == arr[i].length-1-i) {
					sum += arr[i][j];
				}
				if(j == i) {
					sum += arr[i][j];
				}
			}
		}
		if(n%2 != 0) {
			int num = n/2;
			sum = sum - arr[num][num];
		}
		System.out.println("Sum of all the diagonals : "+sum);
		
		sc.close();
	}

}
