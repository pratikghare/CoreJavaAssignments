package com.assignments;

import java.util.Scanner;

public class Question21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int []arr = new int[10];
		
		int sum=0;
		for(int i=0; i<10; i++) {
			System.out.println("Enter element"+(i+1)+" : ");
			int temp = sc.nextInt();
			sum+=temp;
		}
		System.out.println("Average : "+(sum/(double)10));
	}

}
