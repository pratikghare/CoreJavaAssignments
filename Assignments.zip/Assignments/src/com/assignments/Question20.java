package com.assignments;

import java.util.Scanner;

public class Question20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range from start to end : ");
		int start = sc.nextInt();
		int end = sc.nextInt();
		
		System.out.println("Prime numbers between range "+start+" and "+end+" are : ");
		for(int i=start ; i<=end; i++) {
			int count=0;
			for(int j=1; j<=i/2; j++) {
				if(i%j == 0)
					count++;
			}
			if(count == 1)
				System.out.print(i+" ");
		}
		
	}

}
