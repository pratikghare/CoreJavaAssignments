package com.assignments;

public class Question28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arr[] = new String[] {"Pratik", "Pranay", "Ritesh"};
		
		for(String str : arr)
			System.out.println(str);
	}

}
