package com.assignments;

import java.util.Scanner;

public class Question15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		String gender;
		int age;
		char g;
		System.out.println("Enter your gender(m/f) : ");
		g = sc.next().charAt(0);
		System.out.println("Enter your age : ");
		age = sc.nextInt();
		//g = gender.charAt(0);
		
		if(age>=23 && (g=='f' || g=='F')) {
			System.out.println("You are eligible for Marriage.");
		}
		else if(age>=28 && (g=='m' || g=='M')) {
			System.out.println("You are eligible for Marriage.");
		}
		else {
			System.out.println("You are not eligible for Marriage.");
		}
	}

}