package com.assignments;

import java.util.Scanner;
public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		byte a = 5;
		byte b = 10;
		
		byte c = (byte)(a + b);
		
		System.out.println("Ans : "+c);
	}

}

