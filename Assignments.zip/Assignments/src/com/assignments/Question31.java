package com.assignments;

class Students{
	int rno;
	String name;
	
	Students(){
		
	}
	
	Students(int rno, String name){
		this.rno = rno;
		this.name = name;
	}
	
	void setData(int rno, String name) {
		this.rno = rno;
		this.name = name;
	}
	
	void showData() {
		System.out.println("Roll No : "+rno+"\nName : "+name);
	}
}

public class Question31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students s = new Students();
		s.setData(1, "Pratik");
		s.showData();
	}

}
