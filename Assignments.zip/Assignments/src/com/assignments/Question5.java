package com.assignments;

import java.util.Scanner;
public class Question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Welcome ");
//		for(int i=0; i<args.length; i++) {
//			System.out.print(args[i]);
//		}
		System.out.println(args[0]);
		System.out.print("!");
	}

}
