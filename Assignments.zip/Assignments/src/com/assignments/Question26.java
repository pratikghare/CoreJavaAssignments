package com.assignments;

import java.util.*;

public class Question26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int sum =0;
	    int arr[][] = new int[5][];
	    for(int i=0; i<5; i++){
	        
	        if(i<4)
	        {
	            int a[] = new int[3];
	            for(int j=0; j<3; j++){
	                System.out.println("Enter element"+i+j+" : ");
	                a[j] = sc.nextInt();
	                sum+=a[j];
	            }
	            arr[i] = a;
	        }
	        else
	        {
	            int a[] = new int[4];
	            for(int j=0; j<4; j++){
	                System.out.println("Enter element"+i+j+" : ");
	                a[j] = sc.nextInt();
	                sum+=a[j];
	            }
	            arr[i] = a;
	        }
	        
	    }
	    for(int i=0; i<5; i++){
	        
	        if(i<4)
	        {
	            for(int j=0; j<3; j++){
	                System.out.print(arr[i][j]+"\t");
	            }
	        }
	        else
	        {
	            for(int j=0; j<4; j++){
	                System.out.print(arr[i][j]+"\t");
	            }
	        }
	        System.out.println();
	    }
	    System.out.println("Total of all the elements : "+sum);
		
	}
}
