package com.assignments;

import java.util.Scanner;

public class Question22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int[10];
		
		for(int i=0; i<10; i++){
		    System.out.println("Enter element"+(i+1)+" : ");
		    arr[i] = sc.nextInt();
		}
		for(int i=0; i<10; i++){
		    System.out.print(arr[i]+" ");
		}
		
		for(int i=0; i<10; i++){
		    for(int j=0; j<10; j++){
		        if(arr[j]<arr[i]){
		            int temp = arr[j];
		            arr[j] = arr[i];
		            arr[i] = temp;
		        }
		    }
		}
		System.out.println();
		for(int i=0; i<10; i++){
		    System.out.print(arr[i]+" ");
		}
	}
}
