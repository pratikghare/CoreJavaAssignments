package com.assignments;

import java.util.Scanner;

public class Question19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int range;
		System.out.println("Enter the range : ");
		range = sc.nextInt();
		
		int sum = 12;
		int total = sum;
		while(sum<range) {
			if(sum+10 < range)
				System.out.print(sum+" + ");
			else
					System.out.print(sum+" = ");
			sum+=10;
			total+=sum;
		}
		System.out.print(total);
	}

}