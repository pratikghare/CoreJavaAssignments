package com.assignments;

import java.util.*;

class Persons{
    int age;
    String name;
    
    Persons(){
        this.age = 18;
    }
    
    Persons(int age, String name){
        this.age = age;
        this.name = name;
    }
    
    void display(){
        System.out.println("Name : "+this.name+", Age : "+this.age);
    }
}

public class Question37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Persons p1 = new Persons();
	    	Persons p2 = new Persons(24, "Pratik");
	    
	    	p1.display();
	    	p2.display();
		
	}
}