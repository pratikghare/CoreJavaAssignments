package com.assignments;

import java.util.*;

class MathOpe{
    
    static int multiply(int a, int b){
        return a*b;
    }
    
    static float multiply(float a, float b, float c){
        return a*b*c;
    }
    
    static int multiply(int []arr){
        int prod = 1;
        for(int i=0; i<arr.length; i++){
            prod*=arr[i];
        }
        return prod;
    }
    
    static double multiply(double a, int b){
        return a*b;
    }
}

public class Question36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[] {1, 2, 3, 4};
		System.out.println(MathOpe.multiply(10, 20));
		System.out.println(MathOpe.multiply(10.2f, 20.35f, 30.12f));
		System.out.println(MathOpe.multiply(arr));
		System.out.println(MathOpe.multiply(35.215, 10));
		
		
	}
}
