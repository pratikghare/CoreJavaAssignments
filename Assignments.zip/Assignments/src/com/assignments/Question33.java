package com.assignments;

import java.util.*;

class Person{
    int age;
    String name;
    
    Person(){
        age = 24;
        name="Pratik";
    }
    
    Person(int age, String name){
        this.age = age;
        this.name = name;
    }
    
    void show(){
        System.out.println("Name : "+name+", Age : "+age);
    }
}


public class Question33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Person(24, "Pratik");
		p.show();
		
		
	}
}
