package com.assignments;

import java.util.Scanner;

public class Question11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a : ");
		double a = sc.nextDouble();
		System.out.println("Enter b : ");
		double b = sc.nextDouble();
		System.out.println("Before Swap");
		System.out.println("a = "+a+"\tb = "+b);
		
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("Before Swap");
		System.out.println("a = "+a+"\tb = "+b);
	}

}