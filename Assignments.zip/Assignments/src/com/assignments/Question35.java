package com.assignments;

import java.util.*;

class MathOperation{
    
    static int add(int a, int b){
        return a+b;
    }
    
    static int subtract(int a, int b){
        return a-b;
    }
    
    static int multiply(int a, int b){
        return a*b;
    }
    
    static int power(int a, int b){
        int pow = 1;
        for(int i=0; i<b; i++)
            pow*=a;
        return pow;
    }
}

public class Question35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    System.out.println("Enter num1 : ");
	    int num1 = sc.nextInt();
	    System.out.println("Enter num2 : ");
	    int num2 = sc.nextInt();
		System.out.println(MathOperation.add(num1, num2));
		System.out.println(MathOperation.subtract(num1, num2));
		System.out.println(MathOperation.multiply(num1, num2));
		System.out.println(MathOperation.power(num1, num2));
		
		
	}
}
