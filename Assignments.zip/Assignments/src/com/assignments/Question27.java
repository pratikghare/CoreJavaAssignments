package com.assignments;

import java.util.*;

public class Question27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		int min=arr[0];
		int max=arr[0];
		for(int i=0; i<arr.length; i++){
		    if(min>arr[i])
		        min = arr[i];
		    if(max<arr[i])
		        max = arr[i];
		}
		System.out.println("Min : "+min+" Max : "+max);
	}
}
