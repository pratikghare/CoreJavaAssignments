package com.assignments;

import java.util.*;

public class Question24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int[10];
		
		for(int i=0; i<10; i++){
		    System.out.println("Enter element"+(i+1)+" : ");
		    arr[i] = sc.nextInt();
		}
		System.out.println("Enter the element you want to search : ");
		int userElem = sc.nextInt();
		int flag =0;
		for(int i=0; i<10; i++){
		    if(arr[i] == userElem){
		        System.out.println(userElem+" found at index"+i);
		        flag = 1;
		    }
		}
		if(flag == 0)
		    System.out.println(userElem+" not found.");
	}
}
