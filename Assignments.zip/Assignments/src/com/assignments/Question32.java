package com.assignments;

class Students2{
	int rno;
	String name;
	static int count;
	
	Students2(){
		count++;
	}
	
	Students2(int rno, String name){
		this.rno = rno;
		this.name = name;
	}
	
	void setData(int rno, String name) {
		this.rno = rno;
		this.name = name;
	}
	
	void showData() {
		System.out.println("Roll No : "+rno+"\nName : "+name);
	}
}

public class Question32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students2 s = new Students2();
		s.setData(1, "Pratik");
		s.showData();
		
		System.out.println(Students2.count+" Student Object created");
	}

}
