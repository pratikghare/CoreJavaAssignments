package com.assignments;

import java.util.Scanner;
public class Question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the radius of Circle : ");
		double radius = sc.nextInt();
		double pi = 3.14159265;
		double A = pi * radius * radius;
		double C = 2 * pi * radius;
		
		System.out.println("Area = "+A+"   Circumference = "+C);
	}

}