package com.assignments_2;

import java.util.Scanner;

interface StudentFee {
	public void getFee() throws InvalidFeeException;
}


class InvalidFeeException extends Exception{
	InvalidFeeException(String exp){
		super(exp);
	}
}

class StudentImp implements StudentFee{
	double fee;
	@Override
	public void getFee() throws InvalidFeeException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the fees : ");
		this.fee = sc.nextDouble();
		if(this.fee < 0)
			throw new InvalidFeeException("Fee amount should be positive!");
		else
			System.out.println("Fees accepted!");
	}
	
}

public class Question60 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentImp s = new StudentImp();
		try {
			s.getFee();
		} catch (InvalidFeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
